package A;
public class A {
	int i;
	protected int pro;
	private int pri;
	public int pub;
}