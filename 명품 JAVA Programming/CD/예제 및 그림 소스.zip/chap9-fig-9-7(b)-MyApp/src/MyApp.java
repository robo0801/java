import javax.swing.*;

class MyFrame extends JFrame {
	MyFrame() {
		setTitle("ù��° ������");
		setSize(300,300);
		setVisible(true);
	}
}

public class MyApp {
	public static void  main(String [] args) {
		new MyFrame();
	}
}
