interface Stack {
	int length();
	Object pop();
	boolean push(Object ob);
}
