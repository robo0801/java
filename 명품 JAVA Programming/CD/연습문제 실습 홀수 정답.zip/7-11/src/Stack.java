public interface Stack<T> {
	public T pop();
	public boolean push(T ob);
}
