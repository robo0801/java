package main;
import lib.a;

public class m {
	public static void main (String[] args) {
		a aObj = new a();
		System.out.println(aObj.sum(2, 3));
	}
}
