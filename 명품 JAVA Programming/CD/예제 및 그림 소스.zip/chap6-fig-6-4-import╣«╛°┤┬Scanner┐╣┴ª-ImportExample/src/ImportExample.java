public class ImportExample {
	public static void main(String[] args) {
		java.util.Scanner scanner = new java.util.Scanner(System.in);
		System.out.println(scanner.next());
	}
}
